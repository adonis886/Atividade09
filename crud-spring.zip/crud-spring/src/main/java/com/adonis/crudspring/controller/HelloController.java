package com.adonis.crudspring.controller;

import java.lang.reflect.Method;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/hellou")
public class HelloController {
   @GetMapping
   
    public @ResponseBody String hello() {
    return "Hello";
   } 
}
